package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.network.RpgExpansionModVariables;
import net.mcreator.rpgexpansionbynaki.init.RpgExpansionModEntities;
import net.mcreator.rpgexpansionbynaki.entity.BsmcemagicstaffprojectileEntity;

public class BsmcemagicstaffprojectilespawnaltProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof Player _plrCldCheck1 && _plrCldCheck1.getCooldowns().isOnCooldown((entity instanceof LivingEntity _entUseItem0 ? _entUseItem0.getUseItem() : ItemStack.EMPTY).getItem()))) {
			if ((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana >= 2) {
				{
					double _setval = (entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana - 2;
					entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = 20 * 2;
					entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.ManaWait = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					Entity _shootFrom = entity;
					Level projectileLevel = _shootFrom.level();
					if (!projectileLevel.isClientSide()) {
						Projectile _entityToSpawn = new Object() {
							public Projectile getArrow(Level level, Entity shooter, float damage, int knockback) {
								AbstractArrow entityToSpawn = new BsmcemagicstaffprojectileEntity(RpgExpansionModEntities.BSMCEMAGICSTAFFPROJECTILE.get(), level);
								entityToSpawn.setOwner(shooter);
								entityToSpawn.setBaseDamage(damage);
								entityToSpawn.setKnockback(knockback);
								entityToSpawn.setSilent(true);
								return entityToSpawn;
							}
						}.getArrow(projectileLevel, entity, 2, 1);
						_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
						_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 2, (float) 0.1);
						projectileLevel.addFreshEntity(_entityToSpawn);
					}
				}
				if (entity instanceof Player _player)
					_player.getCooldowns().addCooldown((entity instanceof LivingEntity _entUseItem4 ? _entUseItem4.getUseItem() : ItemStack.EMPTY).getItem(), 14);
			}
		}
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.entity.BsmceskeletontalkyEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcemobdarkbossEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcemobaragogEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcemagicstaffprojectileEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcedarkslasherEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcedarkmageEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcedarkknightEntity;
import net.mcreator.rpgexpansionbynaki.RpgExpansionMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpgExpansionModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RpgExpansionMod.MODID);
	public static final RegistryObject<EntityType<BsmcemobaragogEntity>> BSMCEMOBARAGOG = register("bsmcemobaragog",
			EntityType.Builder.<BsmcemobaragogEntity>of(BsmcemobaragogEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcemobaragogEntity::new)

					.sized(1.4f, 0.9f));
	public static final RegistryObject<EntityType<BsmcedarkknightEntity>> BSMCEDARKKNIGHT = register("bsmcedarkknight",
			EntityType.Builder.<BsmcedarkknightEntity>of(BsmcedarkknightEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcedarkknightEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmcedarkslasherEntity>> BSMCEDARKSLASHER = register("bsmcedarkslasher",
			EntityType.Builder.<BsmcedarkslasherEntity>of(BsmcedarkslasherEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcedarkslasherEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmcemobdarkbossEntity>> BSMCEMOBDARKBOSS = register("bsmcemobdarkboss",
			EntityType.Builder.<BsmcemobdarkbossEntity>of(BsmcemobdarkbossEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcemobdarkbossEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmceskeletontalkyEntity>> BSMCESKELETONTALKY = register("bsmceskeletontalky",
			EntityType.Builder.<BsmceskeletontalkyEntity>of(BsmceskeletontalkyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmceskeletontalkyEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmcedarkmageEntity>> BSMCEDARKMAGE = register("bsmcedarkmage",
			EntityType.Builder.<BsmcedarkmageEntity>of(BsmcedarkmageEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcedarkmageEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmcemagicstaffprojectileEntity>> BSMCEMAGICSTAFFPROJECTILE = register("projectile_bsmcemagicstaffprojectile",
			EntityType.Builder.<BsmcemagicstaffprojectileEntity>of(BsmcemagicstaffprojectileEntity::new, MobCategory.MISC).setCustomClientFactory(BsmcemagicstaffprojectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BsmcemobaragogEntity.init();
			BsmcedarkknightEntity.init();
			BsmcedarkslasherEntity.init();
			BsmcemobdarkbossEntity.init();
			BsmceskeletontalkyEntity.init();
			BsmcedarkmageEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BSMCEMOBARAGOG.get(), BsmcemobaragogEntity.createAttributes().build());
		event.put(BSMCEDARKKNIGHT.get(), BsmcedarkknightEntity.createAttributes().build());
		event.put(BSMCEDARKSLASHER.get(), BsmcedarkslasherEntity.createAttributes().build());
		event.put(BSMCEMOBDARKBOSS.get(), BsmcemobdarkbossEntity.createAttributes().build());
		event.put(BSMCESKELETONTALKY.get(), BsmceskeletontalkyEntity.createAttributes().build());
		event.put(BSMCEDARKMAGE.get(), BsmcedarkmageEntity.createAttributes().build());
	}
}

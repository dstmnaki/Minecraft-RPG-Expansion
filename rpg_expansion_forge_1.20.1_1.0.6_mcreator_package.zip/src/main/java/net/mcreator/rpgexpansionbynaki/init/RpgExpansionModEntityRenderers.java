
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.rpgexpansionbynaki.client.renderer.BsmceskeletontalkyRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcemobdarkbossRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcemobaragogRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcedarkslasherRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcedarkmageRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcedarkknightRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpgExpansionModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEMOBARAGOG.get(), BsmcemobaragogRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEDARKKNIGHT.get(), BsmcedarkknightRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEDARKSLASHER.get(), BsmcedarkslasherRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEMOBDARKBOSS.get(), BsmcemobdarkbossRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCESKELETONTALKY.get(), BsmceskeletontalkyRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEDARKMAGE.get(), BsmcedarkmageRenderer::new);
		event.registerEntityRenderer(RpgExpansionModEntities.BSMCEMAGICSTAFFPROJECTILE.get(), ThrownItemRenderer::new);
	}
}

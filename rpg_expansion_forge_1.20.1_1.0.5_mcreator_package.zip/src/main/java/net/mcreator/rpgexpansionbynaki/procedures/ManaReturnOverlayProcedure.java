package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.network.RpgExpansionModVariables;

public class ManaReturnOverlayProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		return new java.text.DecimalFormat("##.##").format((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana) + "/"
				+ new java.text.DecimalFormat("##.##").format((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).ManaMax);
	}
}


package net.mcreator.rpgexpansionbynaki.command;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.common.util.FakePlayerFactory;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.Commands;

import net.mcreator.rpgexpansionbynaki.procedures.BsmcecommandmanasetProcedure;
import net.mcreator.rpgexpansionbynaki.procedures.BsmcecommandmanamaxsetProcedure;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;

@Mod.EventBusSubscriber
public class BsmcecommandsCommand {
	@SubscribeEvent
	public static void registerCommand(RegisterCommandsEvent event) {
		event.getDispatcher().register(Commands.literal("rpgexpansion")

				.then(Commands.argument("mana", StringArgumentType.word())
						.then(Commands.argument("set", StringArgumentType.word()).then(Commands.argument("Amount", DoubleArgumentType.doubleArg(0)).then(Commands.argument("Player", EntityArgument.player()).executes(arguments -> {
							Level world = arguments.getSource().getUnsidedLevel();
							double x = arguments.getSource().getPosition().x();
							double y = arguments.getSource().getPosition().y();
							double z = arguments.getSource().getPosition().z();
							Entity entity = arguments.getSource().getEntity();
							if (entity == null && world instanceof ServerLevel _servLevel)
								entity = FakePlayerFactory.getMinecraft(_servLevel);
							Direction direction = Direction.DOWN;
							if (entity != null)
								direction = entity.getDirection();

							BsmcecommandmanasetProcedure.execute(arguments, entity);
							return 0;
						})))).then(Commands.argument("max", StringArgumentType.word())
								.then(Commands.argument("set", StringArgumentType.word()).then(Commands.argument("Amount", DoubleArgumentType.doubleArg(0)).then(Commands.argument("Player", EntityArgument.player()).executes(arguments -> {
									Level world = arguments.getSource().getUnsidedLevel();
									double x = arguments.getSource().getPosition().x();
									double y = arguments.getSource().getPosition().y();
									double z = arguments.getSource().getPosition().z();
									Entity entity = arguments.getSource().getEntity();
									if (entity == null && world instanceof ServerLevel _servLevel)
										entity = FakePlayerFactory.getMinecraft(_servLevel);
									Direction direction = Direction.DOWN;
									if (entity != null)
										direction = entity.getDirection();

									BsmcecommandmanamaxsetProcedure.execute(arguments);
									return 0;
								})))))));
	}
}

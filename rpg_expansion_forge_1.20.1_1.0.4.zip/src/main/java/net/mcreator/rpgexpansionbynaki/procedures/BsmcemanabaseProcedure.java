package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.RpgExpansionMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BsmcemanabaseProcedure {
	@SubscribeEvent
	public static void onPlayerRespawned(PlayerEvent.PlayerRespawnEvent event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		RpgExpansionMod.queueServerWork(20, () -> {
			if (entity.getPersistentData().getDouble("PlayerMana") < entity.getPersistentData().getDouble("PlayerManaMax")) {
				entity.getPersistentData().putDouble("PlayerMana", (entity.getPersistentData().getDouble("PlayerMana") + 1));
			}
			if (entity.getPersistentData().getDouble("PlayerMana") > entity.getPersistentData().getDouble("PlayerManaMax")) {
				entity.getPersistentData().putDouble("PlayerMana", (entity.getPersistentData().getDouble("PlayerManaMax")));
			}
			if (entity.getPersistentData().getDouble("PlayerMana") < 0) {
				entity.getPersistentData().putDouble("PlayerMana", 0);
			}
			BsmcemanabaseProcedure.execute(world, entity);
		});
	}
}

package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class BsmcemagicstaffprojectileWhileProjectileFlyingTickProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity immediatesourceentity) {
		if (entity == null || immediatesourceentity == null)
			return;
		immediatesourceentity.getPersistentData().putDouble("Despawn", (immediatesourceentity.getPersistentData().getDouble("Despawn") + 1));
		if (!immediatesourceentity.getPersistentData().getBoolean("Grav")) {
			immediatesourceentity.setNoGravity(true);
			immediatesourceentity.getPersistentData().putBoolean("Grav", true);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.chain.hit")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.chain.hit")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
		}
		if (immediatesourceentity.getPersistentData().getDouble("Despawn") >= 100) {
			BsmcemagicstaffprojectileexplodeProcedure.execute(world, immediatesourceentity);
			if (!immediatesourceentity.level().isClientSide())
				immediatesourceentity.discard();
		}
	}
}

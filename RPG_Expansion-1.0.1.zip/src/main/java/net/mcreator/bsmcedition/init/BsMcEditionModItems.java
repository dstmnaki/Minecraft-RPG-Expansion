
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bsmcedition.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.bsmcedition.item.BsmceunobtaniumingotItem;
import net.mcreator.bsmcedition.item.BsmceunobtaniumItem;
import net.mcreator.bsmcedition.item.BsmcesulfurItem;
import net.mcreator.bsmcedition.item.BsmcesapphireItem;
import net.mcreator.bsmcedition.item.BsmcerubyItem;
import net.mcreator.bsmcedition.item.BsmcephoenixswordItem;
import net.mcreator.bsmcedition.item.BsmcephoenixfeatherItem;
import net.mcreator.bsmcedition.item.BsmcemeteoriteshardItem;
import net.mcreator.bsmcedition.item.BsmcemeteoriteoreItem;
import net.mcreator.bsmcedition.item.BsmceiceaxeItem;
import net.mcreator.bsmcedition.item.BsmcehellItem;
import net.mcreator.bsmcedition.item.BsmceheavymetalswordItem;
import net.mcreator.bsmcedition.item.BsmceforgottenskyItem;
import net.mcreator.bsmcedition.item.BsmceflameofcosmicforgeItem;
import net.mcreator.bsmcedition.item.BsmceepicswordItem;
import net.mcreator.bsmcedition.item.BsmceelectriteItem;
import net.mcreator.bsmcedition.item.BsmcecrystalswordItem;
import net.mcreator.bsmcedition.item.BsmcecryptoniteItem;
import net.mcreator.bsmcedition.item.BsmcebattleaxeItem;
import net.mcreator.bsmcedition.item.BsmceangelicswordItem;
import net.mcreator.bsmcedition.item.BsmceamberarmorItem;
import net.mcreator.bsmcedition.BsMcEditionMod;

public class BsMcEditionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BsMcEditionMod.MODID);
	public static final RegistryObject<Item> BSMCERUBY = REGISTRY.register("bsmceruby", () -> new BsmcerubyItem());
	public static final RegistryObject<Item> BSMCERUBYORE = block(BsMcEditionModBlocks.BSMCERUBYORE);
	public static final RegistryObject<Item> BSMCERUBYOREDEEPSLATE = block(BsMcEditionModBlocks.BSMCERUBYOREDEEPSLATE);
	public static final RegistryObject<Item> BSMCEUNOBTANIUMORE = block(BsMcEditionModBlocks.BSMCEUNOBTANIUMORE);
	public static final RegistryObject<Item> BSMCEUNOBTANIUM = REGISTRY.register("bsmceunobtanium", () -> new BsmceunobtaniumItem());
	public static final RegistryObject<Item> BSMCESAPPHIREORE = block(BsMcEditionModBlocks.BSMCESAPPHIREORE);
	public static final RegistryObject<Item> BSMCESAPPHIRE = REGISTRY.register("bsmcesapphire", () -> new BsmcesapphireItem());
	public static final RegistryObject<Item> BSMCESAPPHIREOREDEEPSLATE = block(BsMcEditionModBlocks.BSMCESAPPHIREOREDEEPSLATE);
	public static final RegistryObject<Item> BSMCESULFUR = REGISTRY.register("bsmcesulfur", () -> new BsmcesulfurItem());
	public static final RegistryObject<Item> BSMCECRYPTONITE = REGISTRY.register("bsmcecryptonite", () -> new BsmcecryptoniteItem());
	public static final RegistryObject<Item> BSMCECRYPTONITEORE = block(BsMcEditionModBlocks.BSMCECRYPTONITEORE);
	public static final RegistryObject<Item> BSMCESULFURORE = block(BsMcEditionModBlocks.BSMCESULFURORE);
	public static final RegistryObject<Item> BSMCEMETEORITE = block(BsMcEditionModBlocks.BSMCEMETEORITE);
	public static final RegistryObject<Item> BSMCEMETEORITESHARD = REGISTRY.register("bsmcemeteoriteshard", () -> new BsmcemeteoriteshardItem());
	public static final RegistryObject<Item> BSMCEMETEORITEORE = REGISTRY.register("bsmcemeteoriteore", () -> new BsmcemeteoriteoreItem());
	public static final RegistryObject<Item> BSMCEAMBER = block(BsMcEditionModBlocks.BSMCEAMBER);
	public static final RegistryObject<Item> BSMCEAMBERBRICKS = block(BsMcEditionModBlocks.BSMCEAMBERBRICKS);
	public static final RegistryObject<Item> BSMCEKLORIUM = block(BsMcEditionModBlocks.BSMCEKLORIUM);
	public static final RegistryObject<Item> BSMCEFORGOTTENSTONE = block(BsMcEditionModBlocks.BSMCEFORGOTTENSTONE);
	public static final RegistryObject<Item> BSMCEELECTRITE = REGISTRY.register("bsmceelectrite", () -> new BsmceelectriteItem());
	public static final RegistryObject<Item> BSMCEUNOBTANIUMINGOT = REGISTRY.register("bsmceunobtaniumingot", () -> new BsmceunobtaniumingotItem());
	public static final RegistryObject<Item> BSMCEANGELICSWORD = REGISTRY.register("bsmceangelicsword", () -> new BsmceangelicswordItem());
	public static final RegistryObject<Item> BSMCESKULLBLOCK = block(BsMcEditionModBlocks.BSMCESKULLBLOCK);
	public static final RegistryObject<Item> BSMCEBATTLEAXE = REGISTRY.register("bsmcebattleaxe", () -> new BsmcebattleaxeItem());
	public static final RegistryObject<Item> BSMCECRYSTALSWORD = REGISTRY.register("bsmcecrystalsword", () -> new BsmcecrystalswordItem());
	public static final RegistryObject<Item> BSMCEICEAXE = REGISTRY.register("bsmceiceaxe", () -> new BsmceiceaxeItem());
	public static final RegistryObject<Item> BSMCEFLAMEOFCOSMICFORGE = REGISTRY.register("bsmceflameofcosmicforge", () -> new BsmceflameofcosmicforgeItem());
	public static final RegistryObject<Item> BSMCEHEAVYMETALSWORD = REGISTRY.register("bsmceheavymetalsword", () -> new BsmceheavymetalswordItem());
	public static final RegistryObject<Item> BSMCEPHOENIXFEATHER = REGISTRY.register("bsmcephoenixfeather", () -> new BsmcephoenixfeatherItem());
	public static final RegistryObject<Item> BSMCEPHOENIXSWORD = REGISTRY.register("bsmcephoenixsword", () -> new BsmcephoenixswordItem());
	public static final RegistryObject<Item> BSMCEEPICSWORD = REGISTRY.register("bsmceepicsword", () -> new BsmceepicswordItem());
	public static final RegistryObject<Item> BSMCEUNOBTANIUMBLOCK = block(BsMcEditionModBlocks.BSMCEUNOBTANIUMBLOCK);
	public static final RegistryObject<Item> BSMCECRYPTONITEBLOCK = block(BsMcEditionModBlocks.BSMCECRYPTONITEBLOCK);
	public static final RegistryObject<Item> BSMCERUBYBLOCK = block(BsMcEditionModBlocks.BSMCERUBYBLOCK);
	public static final RegistryObject<Item> BSMCESULFURBLOCK = block(BsMcEditionModBlocks.BSMCESULFURBLOCK);
	public static final RegistryObject<Item> BSMCEMETEORITEOREBLOCK = block(BsMcEditionModBlocks.BSMCEMETEORITEOREBLOCK);
	public static final RegistryObject<Item> BSMCESAPPHIREBLOCK = block(BsMcEditionModBlocks.BSMCESAPPHIREBLOCK);
	public static final RegistryObject<Item> BSMCEAMBERARMOR_HELMET = REGISTRY.register("bsmceamberarmor_helmet", () -> new BsmceamberarmorItem.Helmet());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_CHESTPLATE = REGISTRY.register("bsmceamberarmor_chestplate", () -> new BsmceamberarmorItem.Chestplate());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_LEGGINGS = REGISTRY.register("bsmceamberarmor_leggings", () -> new BsmceamberarmorItem.Leggings());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_BOOTS = REGISTRY.register("bsmceamberarmor_boots", () -> new BsmceamberarmorItem.Boots());
	public static final RegistryObject<Item> BSMCEMOBARAGOG_SPAWN_EGG = REGISTRY.register("bsmcemobaragog_spawn_egg", () -> new ForgeSpawnEggItem(BsMcEditionModEntities.BSMCEMOBARAGOG, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEDARKKNIGHT_SPAWN_EGG = REGISTRY.register("bsmcedarkknight_spawn_egg", () -> new ForgeSpawnEggItem(BsMcEditionModEntities.BSMCEDARKKNIGHT, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEDARKSLASHER_SPAWN_EGG = REGISTRY.register("bsmcedarkslasher_spawn_egg", () -> new ForgeSpawnEggItem(BsMcEditionModEntities.BSMCEDARKSLASHER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEHELL = REGISTRY.register("bsmcehell", () -> new BsmcehellItem());
	public static final RegistryObject<Item> BSMCEFORGOTTENSKY = REGISTRY.register("bsmceforgottensky", () -> new BsmceforgottenskyItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

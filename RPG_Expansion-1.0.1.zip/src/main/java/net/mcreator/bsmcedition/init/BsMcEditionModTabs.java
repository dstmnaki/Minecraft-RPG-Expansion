
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bsmcedition.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.bsmcedition.BsMcEditionMod;

public class BsMcEditionModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BsMcEditionMod.MODID);
	public static final RegistryObject<CreativeModeTab> BSMCEORES = REGISTRY.register("bsmceores",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmceores")).icon(() -> new ItemStack(BsMcEditionModItems.BSMCERUBY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModItems.BSMCERUBY.get());
				tabData.accept(BsMcEditionModItems.BSMCEUNOBTANIUM.get());
				tabData.accept(BsMcEditionModItems.BSMCESAPPHIRE.get());
				tabData.accept(BsMcEditionModItems.BSMCESULFUR.get());
				tabData.accept(BsMcEditionModItems.BSMCECRYPTONITE.get());
				tabData.accept(BsMcEditionModItems.BSMCEMETEORITEORE.get());
				tabData.accept(BsMcEditionModItems.BSMCEUNOBTANIUMINGOT.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEWEAPONS = REGISTRY.register("bsmceweapons",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmceweapons")).icon(() -> new ItemStack(BsMcEditionModItems.BSMCEHEAVYMETALSWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModItems.BSMCEANGELICSWORD.get());
				tabData.accept(BsMcEditionModItems.BSMCEBATTLEAXE.get());
				tabData.accept(BsMcEditionModItems.BSMCECRYSTALSWORD.get());
				tabData.accept(BsMcEditionModItems.BSMCEICEAXE.get());
				tabData.accept(BsMcEditionModItems.BSMCEHEAVYMETALSWORD.get());
				tabData.accept(BsMcEditionModItems.BSMCEPHOENIXSWORD.get());
				tabData.accept(BsMcEditionModItems.BSMCEEPICSWORD.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEBLOCKS = REGISTRY.register("bsmceblocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmceblocks")).icon(() -> new ItemStack(BsMcEditionModBlocks.BSMCEMETEORITE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModBlocks.BSMCERUBYORE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCERUBYOREDEEPSLATE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEUNOBTANIUMORE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESAPPHIREORE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESAPPHIREOREDEEPSLATE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCECRYPTONITEORE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESULFURORE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEMETEORITE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEAMBER.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEAMBERBRICKS.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEKLORIUM.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEFORGOTTENSTONE.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESKULLBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEUNOBTANIUMBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCECRYPTONITEBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCERUBYBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESULFURBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCEMETEORITEOREBLOCK.get().asItem());
				tabData.accept(BsMcEditionModBlocks.BSMCESAPPHIREBLOCK.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEARMOR = REGISTRY.register("bsmcearmor",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmcearmor")).icon(() -> new ItemStack(Items.IRON_CHESTPLATE)).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModItems.BSMCEAMBERARMOR_HELMET.get());
				tabData.accept(BsMcEditionModItems.BSMCEAMBERARMOR_CHESTPLATE.get());
				tabData.accept(BsMcEditionModItems.BSMCEAMBERARMOR_LEGGINGS.get());
				tabData.accept(BsMcEditionModItems.BSMCEAMBERARMOR_BOOTS.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEMOBS = REGISTRY.register("bsmcemobs",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmcemobs")).icon(() -> new ItemStack(Items.ZOMBIE_SPAWN_EGG)).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModItems.BSMCEMOBARAGOG_SPAWN_EGG.get());
				tabData.accept(BsMcEditionModItems.BSMCEDARKKNIGHT_SPAWN_EGG.get());
				tabData.accept(BsMcEditionModItems.BSMCEDARKSLASHER_SPAWN_EGG.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEITEMS = REGISTRY.register("bsmceitems",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.bs_mc_edition.bsmceitems")).icon(() -> new ItemStack(BsMcEditionModItems.BSMCEFLAMEOFCOSMICFORGE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(BsMcEditionModItems.BSMCEMETEORITESHARD.get());
				tabData.accept(BsMcEditionModItems.BSMCEELECTRITE.get());
				tabData.accept(BsMcEditionModItems.BSMCEFLAMEOFCOSMICFORGE.get());
				tabData.accept(BsMcEditionModItems.BSMCEPHOENIXFEATHER.get());
				tabData.accept(BsMcEditionModItems.BSMCEHELL.get());
				tabData.accept(BsMcEditionModItems.BSMCEFORGOTTENSKY.get());
			})

					.build());
}

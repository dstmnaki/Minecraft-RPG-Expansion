
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.bsmcedition.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.WandererTradesEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BsMcEditionModTrades {
	@SubscribeEvent
	public static void registerWanderingTrades(WandererTradesEvent event) {
		event.getGenericTrades().add(new BasicItemListing(new ItemStack(Items.DIAMOND, 20),

				new ItemStack(BsMcEditionModBlocks.BSMCECRYPTONITEORE.get()), 4, 10, 0.05f));
	}

	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.DIAMOND, 25),

					new ItemStack(BsMcEditionModItems.BSMCEELECTRITE.get()), 4, 10, 0.05f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(Items.DIAMOND, 60),

					new ItemStack(BsMcEditionModItems.BSMCEEPICSWORD.get()), 1, 15, 0.05f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(4).add(new BasicItemListing(new ItemStack(Items.DIAMOND, 64), new ItemStack(Items.DIAMOND, 11), new ItemStack(BsMcEditionModItems.BSMCECRYSTALSWORD.get()), 1, 20, 0.05f));
		}
	}
}

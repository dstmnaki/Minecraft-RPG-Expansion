
package net.mcreator.rpgexpansionbynaki.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;

import net.mcreator.rpgexpansionbynaki.entity.BsmcemobaragogEntity;

public class BsmcemobaragogRenderer extends MobRenderer<BsmcemobaragogEntity, SpiderModel<BsmcemobaragogEntity>> {
	public BsmcemobaragogRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(BsmcemobaragogEntity entity) {
		return new ResourceLocation("rpg_expansion_forge_1_20_1:textures/entities/spider.png");
	}
}

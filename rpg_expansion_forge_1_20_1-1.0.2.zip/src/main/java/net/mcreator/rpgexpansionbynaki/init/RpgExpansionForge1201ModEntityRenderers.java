
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcemobaragogRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcedarkslasherRenderer;
import net.mcreator.rpgexpansionbynaki.client.renderer.BsmcedarkknightRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class RpgExpansionForge1201ModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RpgExpansionForge1201ModEntities.BSMCEMOBARAGOG.get(), BsmcemobaragogRenderer::new);
		event.registerEntityRenderer(RpgExpansionForge1201ModEntities.BSMCEDARKKNIGHT.get(), BsmcedarkknightRenderer::new);
		event.registerEntityRenderer(RpgExpansionForge1201ModEntities.BSMCEDARKSLASHER.get(), BsmcedarkslasherRenderer::new);
	}
}

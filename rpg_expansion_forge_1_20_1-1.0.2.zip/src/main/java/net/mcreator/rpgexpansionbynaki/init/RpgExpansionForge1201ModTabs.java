
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.rpgexpansionbynaki.RpgExpansionForge1201Mod;

public class RpgExpansionForge1201ModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RpgExpansionForge1201Mod.MODID);
	public static final RegistryObject<CreativeModeTab> BSMCEORES = REGISTRY.register("bsmceores",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmceores")).icon(() -> new ItemStack(RpgExpansionForge1201ModItems.BSMCERUBY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModItems.BSMCERUBY.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEUNOBTANIUM.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCESAPPHIRE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCESULFUR.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCECRYPTONITE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEMETEORITEORE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEUNOBTANIUMINGOT.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEWEAPONS = REGISTRY.register("bsmceweapons", () -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmceweapons"))
			.icon(() -> new ItemStack(RpgExpansionForge1201ModItems.BSMCEHEAVYMETALSWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEANGELICSWORD.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEBATTLEAXE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCECRYSTALSWORD.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEICEAXE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEHEAVYMETALSWORD.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEPHOENIXSWORD.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEEPICSWORD.get());
			})

			.build());
	public static final RegistryObject<CreativeModeTab> BSMCEBLOCKS = REGISTRY.register("bsmceblocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmceblocks")).icon(() -> new ItemStack(RpgExpansionForge1201ModBlocks.BSMCEMETEORITE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCERUBYORE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCERUBYOREDEEPSLATE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEUNOBTANIUMORE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESAPPHIREORE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESAPPHIREOREDEEPSLATE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCECRYPTONITEORE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESULFURORE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEMETEORITE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEAMBER.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEAMBERBRICKS.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEKLORIUM.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEFORGOTTENSTONE.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESKULLBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEUNOBTANIUMBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCECRYPTONITEBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCERUBYBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESULFURBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCEMETEORITEOREBLOCK.get().asItem());
				tabData.accept(RpgExpansionForge1201ModBlocks.BSMCESAPPHIREBLOCK.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEARMOR = REGISTRY.register("bsmcearmor",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmcearmor")).icon(() -> new ItemStack(Items.IRON_CHESTPLATE)).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEAMBERARMOR_HELMET.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEAMBERARMOR_CHESTPLATE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEAMBERARMOR_LEGGINGS.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEAMBERARMOR_BOOTS.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEMOBS = REGISTRY.register("bsmcemobs",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmcemobs")).icon(() -> new ItemStack(Items.ZOMBIE_SPAWN_EGG)).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEMOBARAGOG_SPAWN_EGG.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEDARKKNIGHT_SPAWN_EGG.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEDARKSLASHER_SPAWN_EGG.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEITEMS = REGISTRY.register("bsmceitems", () -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion_forge_1_20_1.bsmceitems"))
			.icon(() -> new ItemStack(RpgExpansionForge1201ModItems.BSMCEFLAMEOFCOSMICFORGE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEMETEORITESHARD.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEELECTRITE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEFLAMEOFCOSMICFORGE.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEPHOENIXFEATHER.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEHELL.get());
				tabData.accept(RpgExpansionForge1201ModItems.BSMCEFORGOTTENSKY.get());
			})

			.build());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.rpgexpansionbynaki.block.BsmceunobtaniumoreBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceunobtaniumblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcesulfuroreBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcesulfurblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceskullblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcesapphireoredeepslateBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcesapphireoreBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcesapphireblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcerubyoredeepslateBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcerubyoreBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcerubyblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcemeteoriteoreblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcemeteoriteBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcekloriumBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcehellPortalBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceforgottenstoneBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceforgottenskyPortalBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcecryptoniteoreBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmcecryptoniteblockBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceamberbricksBlock;
import net.mcreator.rpgexpansionbynaki.block.BsmceamberBlock;
import net.mcreator.rpgexpansionbynaki.RpgExpansionForge1201Mod;

public class RpgExpansionForge1201ModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RpgExpansionForge1201Mod.MODID);
	public static final RegistryObject<Block> BSMCERUBYORE = REGISTRY.register("bsmcerubyore", () -> new BsmcerubyoreBlock());
	public static final RegistryObject<Block> BSMCERUBYOREDEEPSLATE = REGISTRY.register("bsmcerubyoredeepslate", () -> new BsmcerubyoredeepslateBlock());
	public static final RegistryObject<Block> BSMCEUNOBTANIUMORE = REGISTRY.register("bsmceunobtaniumore", () -> new BsmceunobtaniumoreBlock());
	public static final RegistryObject<Block> BSMCESAPPHIREORE = REGISTRY.register("bsmcesapphireore", () -> new BsmcesapphireoreBlock());
	public static final RegistryObject<Block> BSMCESAPPHIREOREDEEPSLATE = REGISTRY.register("bsmcesapphireoredeepslate", () -> new BsmcesapphireoredeepslateBlock());
	public static final RegistryObject<Block> BSMCECRYPTONITEORE = REGISTRY.register("bsmcecryptoniteore", () -> new BsmcecryptoniteoreBlock());
	public static final RegistryObject<Block> BSMCESULFURORE = REGISTRY.register("bsmcesulfurore", () -> new BsmcesulfuroreBlock());
	public static final RegistryObject<Block> BSMCEMETEORITE = REGISTRY.register("bsmcemeteorite", () -> new BsmcemeteoriteBlock());
	public static final RegistryObject<Block> BSMCEAMBER = REGISTRY.register("bsmceamber", () -> new BsmceamberBlock());
	public static final RegistryObject<Block> BSMCEAMBERBRICKS = REGISTRY.register("bsmceamberbricks", () -> new BsmceamberbricksBlock());
	public static final RegistryObject<Block> BSMCEKLORIUM = REGISTRY.register("bsmceklorium", () -> new BsmcekloriumBlock());
	public static final RegistryObject<Block> BSMCEFORGOTTENSTONE = REGISTRY.register("bsmceforgottenstone", () -> new BsmceforgottenstoneBlock());
	public static final RegistryObject<Block> BSMCESKULLBLOCK = REGISTRY.register("bsmceskullblock", () -> new BsmceskullblockBlock());
	public static final RegistryObject<Block> BSMCEUNOBTANIUMBLOCK = REGISTRY.register("bsmceunobtaniumblock", () -> new BsmceunobtaniumblockBlock());
	public static final RegistryObject<Block> BSMCECRYPTONITEBLOCK = REGISTRY.register("bsmcecryptoniteblock", () -> new BsmcecryptoniteblockBlock());
	public static final RegistryObject<Block> BSMCERUBYBLOCK = REGISTRY.register("bsmcerubyblock", () -> new BsmcerubyblockBlock());
	public static final RegistryObject<Block> BSMCESULFURBLOCK = REGISTRY.register("bsmcesulfurblock", () -> new BsmcesulfurblockBlock());
	public static final RegistryObject<Block> BSMCEMETEORITEOREBLOCK = REGISTRY.register("bsmcemeteoriteoreblock", () -> new BsmcemeteoriteoreblockBlock());
	public static final RegistryObject<Block> BSMCESAPPHIREBLOCK = REGISTRY.register("bsmcesapphireblock", () -> new BsmcesapphireblockBlock());
	public static final RegistryObject<Block> BSMCEHELL_PORTAL = REGISTRY.register("bsmcehell_portal", () -> new BsmcehellPortalBlock());
	public static final RegistryObject<Block> BSMCEFORGOTTENSKY_PORTAL = REGISTRY.register("bsmceforgottensky_portal", () -> new BsmceforgottenskyPortalBlock());
}

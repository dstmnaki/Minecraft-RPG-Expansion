
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.entity.BsmcemobaragogEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcedarkslasherEntity;
import net.mcreator.rpgexpansionbynaki.entity.BsmcedarkknightEntity;
import net.mcreator.rpgexpansionbynaki.RpgExpansionForge1201Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RpgExpansionForge1201ModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RpgExpansionForge1201Mod.MODID);
	public static final RegistryObject<EntityType<BsmcemobaragogEntity>> BSMCEMOBARAGOG = register("bsmcemobaragog",
			EntityType.Builder.<BsmcemobaragogEntity>of(BsmcemobaragogEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcemobaragogEntity::new)

					.sized(1.4f, 0.9f));
	public static final RegistryObject<EntityType<BsmcedarkknightEntity>> BSMCEDARKKNIGHT = register("bsmcedarkknight",
			EntityType.Builder.<BsmcedarkknightEntity>of(BsmcedarkknightEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcedarkknightEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BsmcedarkslasherEntity>> BSMCEDARKSLASHER = register("bsmcedarkslasher",
			EntityType.Builder.<BsmcedarkslasherEntity>of(BsmcedarkslasherEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BsmcedarkslasherEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BsmcemobaragogEntity.init();
			BsmcedarkknightEntity.init();
			BsmcedarkslasherEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BSMCEMOBARAGOG.get(), BsmcemobaragogEntity.createAttributes().build());
		event.put(BSMCEDARKKNIGHT.get(), BsmcedarkknightEntity.createAttributes().build());
		event.put(BSMCEDARKSLASHER.get(), BsmcedarkslasherEntity.createAttributes().build());
	}
}

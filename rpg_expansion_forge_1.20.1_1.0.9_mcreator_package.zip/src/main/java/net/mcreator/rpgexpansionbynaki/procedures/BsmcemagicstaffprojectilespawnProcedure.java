package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.network.RpgExpansionModVariables;
import net.mcreator.rpgexpansionbynaki.init.RpgExpansionModItems;
import net.mcreator.rpgexpansionbynaki.init.RpgExpansionModEntities;
import net.mcreator.rpgexpansionbynaki.entity.BsmcemagicstaffprojectileEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BsmcemagicstaffprojectilespawnProcedure {
	@SubscribeEvent
	public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
		if (event.getHand() != event.getEntity().getUsedItemHand())
			return;
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == RpgExpansionModItems.BSMCEMAGICSTAFF.get()) {
			if (!(entity instanceof Player _plrCldCheck3 && _plrCldCheck3.getCooldowns().isOnCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()))) {
				if ((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana >= 2) {
					{
						double _setval = (entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana - 2;
						entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.Mana = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					{
						double _setval = 20 * 2;
						entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.ManaWait = _setval;
							capability.syncPlayerVariables(entity);
						});
					}
					{
						Entity _shootFrom = entity;
						Level projectileLevel = _shootFrom.level();
						if (!projectileLevel.isClientSide()) {
							Projectile _entityToSpawn = new Object() {
								public Projectile getArrow(Level level, Entity shooter, float damage, int knockback) {
									AbstractArrow entityToSpawn = new BsmcemagicstaffprojectileEntity(RpgExpansionModEntities.BSMCEMAGICSTAFFPROJECTILE.get(), level);
									entityToSpawn.setOwner(shooter);
									entityToSpawn.setBaseDamage(damage);
									entityToSpawn.setKnockback(knockback);
									entityToSpawn.setSilent(true);
									return entityToSpawn;
								}
							}.getArrow(projectileLevel, entity, 2, 1);
							_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
							_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 2, (float) 0.1);
							projectileLevel.addFreshEntity(_entityToSpawn);
						}
					}
					if (entity instanceof Player _player)
						_player.getCooldowns().addCooldown((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem(), 14);
				}
			}
		}
	}
}

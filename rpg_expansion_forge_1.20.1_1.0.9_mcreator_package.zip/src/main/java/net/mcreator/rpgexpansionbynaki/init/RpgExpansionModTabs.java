
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.rpgexpansionbynaki.RpgExpansionMod;

public class RpgExpansionModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RpgExpansionMod.MODID);
	public static final RegistryObject<CreativeModeTab> BSMCEORES = REGISTRY.register("bsmceores",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmceores")).icon(() -> new ItemStack(RpgExpansionModItems.BSMCERUBY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModItems.BSMCERUBY.get());
				tabData.accept(RpgExpansionModItems.BSMCEUNOBTANIUM.get());
				tabData.accept(RpgExpansionModItems.BSMCESAPPHIRE.get());
				tabData.accept(RpgExpansionModItems.BSMCESULFUR.get());
				tabData.accept(RpgExpansionModItems.BSMCECRYPTONITE.get());
				tabData.accept(RpgExpansionModItems.BSMCEMETEORITEORE.get());
				tabData.accept(RpgExpansionModItems.BSMCEUNOBTANIUMINGOT.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEWEAPONS = REGISTRY.register("bsmceweapons",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmceweapons")).icon(() -> new ItemStack(RpgExpansionModItems.BSMCEHEAVYMETALSWORD.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModItems.BSMCEANGELICSWORD.get());
				tabData.accept(RpgExpansionModItems.BSMCEBATTLEAXE.get());
				tabData.accept(RpgExpansionModItems.BSMCECRYSTALSWORD.get());
				tabData.accept(RpgExpansionModItems.BSMCEICEAXE.get());
				tabData.accept(RpgExpansionModItems.BSMCEHEAVYMETALSWORD.get());
				tabData.accept(RpgExpansionModItems.BSMCEPHOENIXSWORD.get());
				tabData.accept(RpgExpansionModItems.BSMCEEPICSWORD.get());
				tabData.accept(RpgExpansionModItems.BSMCEMAGICSTAFF.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEBLOCKS = REGISTRY.register("bsmceblocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmceblocks")).icon(() -> new ItemStack(RpgExpansionModBlocks.BSMCEAMBERBRICKS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModBlocks.BSMCERUBYORE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCERUBYOREDEEPSLATE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEUNOBTANIUMORE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESAPPHIREORE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESAPPHIREOREDEEPSLATE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCECRYPTONITEORE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESULFURORE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEMETEORITE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEAMBER.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEAMBERBRICKS.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEKLORIUM.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEFORGOTTENSTONE.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESKULLBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEUNOBTANIUMBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCECRYPTONITEBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCERUBYBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESULFURBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCEMETEORITEOREBLOCK.get().asItem());
				tabData.accept(RpgExpansionModBlocks.BSMCESAPPHIREBLOCK.get().asItem());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEARMOR = REGISTRY.register("bsmcearmor",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmcearmor")).icon(() -> new ItemStack(RpgExpansionModItems.BSMCEAMBERARMOR_CHESTPLATE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModItems.BSMCEAMBERARMOR_HELMET.get());
				tabData.accept(RpgExpansionModItems.BSMCEAMBERARMOR_CHESTPLATE.get());
				tabData.accept(RpgExpansionModItems.BSMCEAMBERARMOR_LEGGINGS.get());
				tabData.accept(RpgExpansionModItems.BSMCEAMBERARMOR_BOOTS.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEMOBS = REGISTRY.register("bsmcemobs",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmcemobs")).icon(() -> new ItemStack(Items.ZOMBIE_SPAWN_EGG)).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModItems.BSMCEMOBARAGOG_SPAWN_EGG.get());
				tabData.accept(RpgExpansionModItems.BSMCEDARKKNIGHT_SPAWN_EGG.get());
				tabData.accept(RpgExpansionModItems.BSMCEDARKSLASHER_SPAWN_EGG.get());
				tabData.accept(RpgExpansionModItems.BSMCEMOBDARKBOSS_SPAWN_EGG.get());
				tabData.accept(RpgExpansionModItems.BSMCESKELETONTALKY_SPAWN_EGG.get());
				tabData.accept(RpgExpansionModItems.BSMCEDARKMAGE_SPAWN_EGG.get());
			})

					.build());
	public static final RegistryObject<CreativeModeTab> BSMCEITEMS = REGISTRY.register("bsmceitems",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.rpg_expansion.bsmceitems")).icon(() -> new ItemStack(RpgExpansionModItems.BSMCEFLAMEOFCOSMICFORGE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RpgExpansionModItems.BSMCEMETEORITESHARD.get());
				tabData.accept(RpgExpansionModItems.BSMCEELECTRITE.get());
				tabData.accept(RpgExpansionModItems.BSMCEFLAMEOFCOSMICFORGE.get());
				tabData.accept(RpgExpansionModItems.BSMCEPHOENIXFEATHER.get());
				tabData.accept(RpgExpansionModItems.BSMCEFORGOTTENSKY.get());
				tabData.accept(RpgExpansionModItems.BSMCEMANAPOTION.get());
				tabData.accept(RpgExpansionModItems.BSMCEMANAPOTIONSPECIAL.get());
			})

					.build());
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bsmcedition.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.bsmcedition.client.renderer.BsmcemobaragogRenderer;
import net.mcreator.bsmcedition.client.renderer.BsmcedarkslasherRenderer;
import net.mcreator.bsmcedition.client.renderer.BsmcedarkknightRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class BsMcEditionModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(BsMcEditionModEntities.BSMCEMOBARAGOG.get(), BsmcemobaragogRenderer::new);
		event.registerEntityRenderer(BsMcEditionModEntities.BSMCEDARKKNIGHT.get(), BsmcedarkknightRenderer::new);
		event.registerEntityRenderer(BsMcEditionModEntities.BSMCEDARKSLASHER.get(), BsmcedarkslasherRenderer::new);
	}
}

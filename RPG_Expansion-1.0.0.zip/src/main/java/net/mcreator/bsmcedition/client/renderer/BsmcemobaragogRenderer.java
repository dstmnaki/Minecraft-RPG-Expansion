
package net.mcreator.bsmcedition.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;

import net.mcreator.bsmcedition.entity.BsmcemobaragogEntity;

public class BsmcemobaragogRenderer extends MobRenderer<BsmcemobaragogEntity, SpiderModel<BsmcemobaragogEntity>> {
	public BsmcemobaragogRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(BsmcemobaragogEntity entity) {
		return new ResourceLocation("bs_mc_edition:textures/entities/spider.png");
	}
}

package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.network.RpgExpansionModVariables;

public class BsmcemanapotionPlayerFinishesUsingItemProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana < (entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new RpgExpansionModVariables.PlayerVariables())).ManaMax) {
			{
				double _setval = (entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana + 4;
				entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.Mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}

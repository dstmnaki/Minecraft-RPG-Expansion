package net.mcreator.rpgexpansionbynaki.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.rpgexpansionbynaki.network.RpgExpansionModVariables;

public class BsmcetoggleflightOnKeyPressedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).ManaFlight == false) {
			if ((entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new RpgExpansionModVariables.PlayerVariables())).Mana > 0) {
				{
					boolean _setval = true;
					entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.ManaFlight = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		} else {
			{
				boolean _setval = false;
				entity.getCapability(RpgExpansionModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.ManaFlight = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		BsmcecanflyProcedure.execute(world, entity);
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.rpgexpansionbynaki.item.BsmceunobtaniumingotItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceunobtaniumItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcesulfurItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcesapphireItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcerubyItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcephoenixswordItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcephoenixfeatherItem;
import net.mcreator.rpgexpansionbynaki.item.Bsmcemusicdisc2Item;
import net.mcreator.rpgexpansionbynaki.item.Bsmcemusicdisc1Item;
import net.mcreator.rpgexpansionbynaki.item.BsmcemeteoriteshardItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcemeteoriteoreItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcemanapotionspecialItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcemanapotionItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcemagicstaffItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcemagicprojectileItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceiceaxeItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceheavymetalswordItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceforgottenskyItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceflameofcosmicforgeItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceepicswordItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceelectriteItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcecrystalswordItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcecryptoniteItem;
import net.mcreator.rpgexpansionbynaki.item.BsmcebattleaxeItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceangelicswordItem;
import net.mcreator.rpgexpansionbynaki.item.BsmceamberarmorItem;
import net.mcreator.rpgexpansionbynaki.RpgExpansionMod;

public class RpgExpansionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RpgExpansionMod.MODID);
	public static final RegistryObject<Item> BSMCERUBY = REGISTRY.register("bsmceruby", () -> new BsmcerubyItem());
	public static final RegistryObject<Item> BSMCERUBYORE = block(RpgExpansionModBlocks.BSMCERUBYORE);
	public static final RegistryObject<Item> BSMCERUBYOREDEEPSLATE = block(RpgExpansionModBlocks.BSMCERUBYOREDEEPSLATE);
	public static final RegistryObject<Item> BSMCEUNOBTANIUMORE = block(RpgExpansionModBlocks.BSMCEUNOBTANIUMORE);
	public static final RegistryObject<Item> BSMCEUNOBTANIUM = REGISTRY.register("bsmceunobtanium", () -> new BsmceunobtaniumItem());
	public static final RegistryObject<Item> BSMCESAPPHIREORE = block(RpgExpansionModBlocks.BSMCESAPPHIREORE);
	public static final RegistryObject<Item> BSMCESAPPHIRE = REGISTRY.register("bsmcesapphire", () -> new BsmcesapphireItem());
	public static final RegistryObject<Item> BSMCESAPPHIREOREDEEPSLATE = block(RpgExpansionModBlocks.BSMCESAPPHIREOREDEEPSLATE);
	public static final RegistryObject<Item> BSMCESULFUR = REGISTRY.register("bsmcesulfur", () -> new BsmcesulfurItem());
	public static final RegistryObject<Item> BSMCECRYPTONITE = REGISTRY.register("bsmcecryptonite", () -> new BsmcecryptoniteItem());
	public static final RegistryObject<Item> BSMCECRYPTONITEORE = block(RpgExpansionModBlocks.BSMCECRYPTONITEORE);
	public static final RegistryObject<Item> BSMCESULFURORE = block(RpgExpansionModBlocks.BSMCESULFURORE);
	public static final RegistryObject<Item> BSMCEMETEORITE = block(RpgExpansionModBlocks.BSMCEMETEORITE);
	public static final RegistryObject<Item> BSMCEMETEORITESHARD = REGISTRY.register("bsmcemeteoriteshard", () -> new BsmcemeteoriteshardItem());
	public static final RegistryObject<Item> BSMCEMETEORITEORE = REGISTRY.register("bsmcemeteoriteore", () -> new BsmcemeteoriteoreItem());
	public static final RegistryObject<Item> BSMCEAMBER = block(RpgExpansionModBlocks.BSMCEAMBER);
	public static final RegistryObject<Item> BSMCEAMBERBRICKS = block(RpgExpansionModBlocks.BSMCEAMBERBRICKS);
	public static final RegistryObject<Item> BSMCEKLORIUM = block(RpgExpansionModBlocks.BSMCEKLORIUM);
	public static final RegistryObject<Item> BSMCEFORGOTTENSTONE = block(RpgExpansionModBlocks.BSMCEFORGOTTENSTONE);
	public static final RegistryObject<Item> BSMCEELECTRITE = REGISTRY.register("bsmceelectrite", () -> new BsmceelectriteItem());
	public static final RegistryObject<Item> BSMCEUNOBTANIUMINGOT = REGISTRY.register("bsmceunobtaniumingot", () -> new BsmceunobtaniumingotItem());
	public static final RegistryObject<Item> BSMCEANGELICSWORD = REGISTRY.register("bsmceangelicsword", () -> new BsmceangelicswordItem());
	public static final RegistryObject<Item> BSMCESKULLBLOCK = block(RpgExpansionModBlocks.BSMCESKULLBLOCK);
	public static final RegistryObject<Item> BSMCEBATTLEAXE = REGISTRY.register("bsmcebattleaxe", () -> new BsmcebattleaxeItem());
	public static final RegistryObject<Item> BSMCECRYSTALSWORD = REGISTRY.register("bsmcecrystalsword", () -> new BsmcecrystalswordItem());
	public static final RegistryObject<Item> BSMCEICEAXE = REGISTRY.register("bsmceiceaxe", () -> new BsmceiceaxeItem());
	public static final RegistryObject<Item> BSMCEFLAMEOFCOSMICFORGE = REGISTRY.register("bsmceflameofcosmicforge", () -> new BsmceflameofcosmicforgeItem());
	public static final RegistryObject<Item> BSMCEHEAVYMETALSWORD = REGISTRY.register("bsmceheavymetalsword", () -> new BsmceheavymetalswordItem());
	public static final RegistryObject<Item> BSMCEPHOENIXFEATHER = REGISTRY.register("bsmcephoenixfeather", () -> new BsmcephoenixfeatherItem());
	public static final RegistryObject<Item> BSMCEPHOENIXSWORD = REGISTRY.register("bsmcephoenixsword", () -> new BsmcephoenixswordItem());
	public static final RegistryObject<Item> BSMCEEPICSWORD = REGISTRY.register("bsmceepicsword", () -> new BsmceepicswordItem());
	public static final RegistryObject<Item> BSMCEUNOBTANIUMBLOCK = block(RpgExpansionModBlocks.BSMCEUNOBTANIUMBLOCK);
	public static final RegistryObject<Item> BSMCECRYPTONITEBLOCK = block(RpgExpansionModBlocks.BSMCECRYPTONITEBLOCK);
	public static final RegistryObject<Item> BSMCERUBYBLOCK = block(RpgExpansionModBlocks.BSMCERUBYBLOCK);
	public static final RegistryObject<Item> BSMCESULFURBLOCK = block(RpgExpansionModBlocks.BSMCESULFURBLOCK);
	public static final RegistryObject<Item> BSMCEMETEORITEOREBLOCK = block(RpgExpansionModBlocks.BSMCEMETEORITEOREBLOCK);
	public static final RegistryObject<Item> BSMCESAPPHIREBLOCK = block(RpgExpansionModBlocks.BSMCESAPPHIREBLOCK);
	public static final RegistryObject<Item> BSMCEAMBERARMOR_HELMET = REGISTRY.register("bsmceamberarmor_helmet", () -> new BsmceamberarmorItem.Helmet());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_CHESTPLATE = REGISTRY.register("bsmceamberarmor_chestplate", () -> new BsmceamberarmorItem.Chestplate());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_LEGGINGS = REGISTRY.register("bsmceamberarmor_leggings", () -> new BsmceamberarmorItem.Leggings());
	public static final RegistryObject<Item> BSMCEAMBERARMOR_BOOTS = REGISTRY.register("bsmceamberarmor_boots", () -> new BsmceamberarmorItem.Boots());
	public static final RegistryObject<Item> BSMCEMOBARAGOG_SPAWN_EGG = REGISTRY.register("bsmcemobaragog_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCEMOBARAGOG, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEDARKKNIGHT_SPAWN_EGG = REGISTRY.register("bsmcedarkknight_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCEDARKKNIGHT, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEDARKSLASHER_SPAWN_EGG = REGISTRY.register("bsmcedarkslasher_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCEDARKSLASHER, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEFORGOTTENSKY = REGISTRY.register("bsmceforgottensky", () -> new BsmceforgottenskyItem());
	public static final RegistryObject<Item> BSMCEMOBDARKBOSS_SPAWN_EGG = REGISTRY.register("bsmcemobdarkboss_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCEMOBDARKBOSS, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCESKELETONTALKY_SPAWN_EGG = REGISTRY.register("bsmceskeletontalky_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCESKELETONTALKY, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEDARKMAGE_SPAWN_EGG = REGISTRY.register("bsmcedarkmage_spawn_egg", () -> new ForgeSpawnEggItem(RpgExpansionModEntities.BSMCEDARKMAGE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> BSMCEMAGICSTAFF = REGISTRY.register("bsmcemagicstaff", () -> new BsmcemagicstaffItem());
	public static final RegistryObject<Item> BSMCEMANAPOTION = REGISTRY.register("bsmcemanapotion", () -> new BsmcemanapotionItem());
	public static final RegistryObject<Item> BSMCEMANAPOTIONSPECIAL = REGISTRY.register("bsmcemanapotionspecial", () -> new BsmcemanapotionspecialItem());
	public static final RegistryObject<Item> BSMCEMAGICPROJECTILE = REGISTRY.register("bsmcemagicprojectile", () -> new BsmcemagicprojectileItem());
	public static final RegistryObject<Item> BSMCEMUSICDISC_1 = REGISTRY.register("bsmcemusicdisc_1", () -> new Bsmcemusicdisc1Item());
	public static final RegistryObject<Item> BSMCEMUSICDISC_2 = REGISTRY.register("bsmcemusicdisc_2", () -> new Bsmcemusicdisc2Item());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}

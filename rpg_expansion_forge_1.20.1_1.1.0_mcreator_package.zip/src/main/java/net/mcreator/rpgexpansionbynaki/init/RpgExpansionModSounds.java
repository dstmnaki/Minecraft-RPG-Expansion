
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rpgexpansionbynaki.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.rpgexpansionbynaki.RpgExpansionMod;

public class RpgExpansionModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, RpgExpansionMod.MODID);
	public static final RegistryObject<SoundEvent> BSMCE_NEW_GROUNDS_SOUNDTRACK = REGISTRY.register("bsmce_new_grounds_soundtrack", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rpg_expansion", "bsmce_new_grounds_soundtrack")));
	public static final RegistryObject<SoundEvent> BSMCE_THE_SETTING_SUN_SOUNDTRACK = REGISTRY.register("bsmce_the_setting_sun_soundtrack",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rpg_expansion", "bsmce_the_setting_sun_soundtrack")));
	public static final RegistryObject<SoundEvent> BSMCE_FORGOTTEN_SKY_MUSIC = REGISTRY.register("bsmce_forgotten_sky_music", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("rpg_expansion", "bsmce_forgotten_sky_music")));
}

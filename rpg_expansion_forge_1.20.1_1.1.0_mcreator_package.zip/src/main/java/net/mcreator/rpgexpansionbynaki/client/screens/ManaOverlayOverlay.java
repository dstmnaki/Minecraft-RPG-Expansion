
package net.mcreator.rpgexpansionbynaki.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.Minecraft;

import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan9Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan8Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan7Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan6Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan5Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan4Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan3Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan2Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan1Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan19Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan18Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan17Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan16Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan15Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan14Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan13Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan12Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan11Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan10Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamorethan0Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan9Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan8Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan7Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan6Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan5Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan4Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan3Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan2Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan1Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.Manamaxmorethan0Procedure;
import net.mcreator.rpgexpansionbynaki.procedures.ManaFlightIndicatorProcedure;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@Mod.EventBusSubscriber({Dist.CLIENT})
public class ManaOverlayOverlay {
	@SubscribeEvent(priority = EventPriority.HIGH)
	public static void eventHandler(RenderGuiEvent.Pre event) {
		int w = event.getWindow().getGuiScaledWidth();
		int h = event.getWindow().getGuiScaledHeight();
		Level world = null;
		double x = 0;
		double y = 0;
		double z = 0;
		Player entity = Minecraft.getInstance().player;
		if (entity != null) {
			world = entity.level();
			x = entity.getX();
			y = entity.getY();
			z = entity.getZ();
		}
		RenderSystem.disableDepthTest();
		RenderSystem.depthMask(false);
		RenderSystem.enableBlend();
		RenderSystem.setShader(GameRenderer::getPositionTexShader);
		RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		RenderSystem.setShaderColor(1, 1, 1, 1);
		if (true) {
			if (Manamaxmorethan0Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 2, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan1Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 18, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan2Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 34, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan3Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 50, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan4Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 66, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan5Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 82, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan6Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 98, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan7Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 114, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan8Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 130, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamaxmorethan9Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_empty.png"), 146, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan0Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 2, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan2Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 18, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan4Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 34, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan6Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 50, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan8Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 66, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan10Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 82, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan12Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 98, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan14Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 114, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan16Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 130, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan18Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_half.png"), 146, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan1Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 2, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan3Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 18, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan5Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 34, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan7Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 50, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan9Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 66, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan11Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 82, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan13Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 98, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan15Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 114, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan17Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 130, 2, 0, 0, 16, 16, 16, 16);
			}
			if (Manamorethan19Procedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/mana_indicator_full.png"), 146, 2, 0, 0, 16, 16, 16, 16);
			}
			if (ManaFlightIndicatorProcedure.execute(entity)) {
				event.getGuiGraphics().blit(new ResourceLocation("rpg_expansion:textures/screens/flight_indicator_on.png"), w / 2 + 98, h - 19, 0, 0, 16, 16, 16, 16);
			}
		}
		RenderSystem.depthMask(true);
		RenderSystem.defaultBlendFunc();
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.setShaderColor(1, 1, 1, 1);
	}
}
